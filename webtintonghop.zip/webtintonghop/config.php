<?php
  const DB_HOST = 'localhost';
  const DB_USERNAME = 'root';
  const DB_PASSWORD = "";
  const DB_NAME = "dbtintonghop";
  const BASE_DIR = "/webtintonghop/";
  const PAGE_SIZE = 10;
  const NUM_RELATED_POST = 3;
  const NUM_POST_HOMEPAGE = 20;
  
  
  
  