<?php
   $site_info = [
      'email' => 'admintintuchay@gmail.com',
      'phone' => '09123123456',
      'diachi'=>'123, cung Vàng, điện Ngọc, thành phố Trăng Vàng',
      'tenAdmin' => 'Cao Thị Chót Vót',
      'tenWebsite'=>'Tin tức tổng hợp',
      'gioithieu'=>''
   ]
 ?>
      